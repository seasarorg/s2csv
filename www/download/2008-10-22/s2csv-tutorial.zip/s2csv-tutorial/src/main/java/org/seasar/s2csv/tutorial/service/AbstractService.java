package org.seasar.s2csv.tutorial.service;

import org.seasar.extension.jdbc.service.S2AbstractService;

public abstract class AbstractService<ENTITY> extends S2AbstractService<ENTITY> {

}